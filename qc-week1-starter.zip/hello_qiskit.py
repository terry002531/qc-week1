from qiskit import QuantumCircuit, transpile
try:
    from qiskit_aer import Aer
except Exception as e:
    raise SystemExit("请先安装 qiskit-aer：python -m pip install qiskit-aer") from e

qc = QuantumCircuit(1, 1)
qc.h(0)
qc.measure(0, 0)

backend = Aer.get_backend("aer_simulator")
tqc = transpile(qc, backend)
res = backend.run(tqc, shots=2000).result()
print(res.get_counts())
