from typing import List

Matrix = List[List[complex]]

def matmul_complex(A: Matrix, B: Matrix) -> Matrix:
    """朴素 O(n^3) 复数矩阵相乘（请补全实现）。
    要求：
    - 维度检查：A 是 n×m，B 是 m×p
    - 使用内层三重循环：i, k, j
    - 用 Python 内置 complex 完成复数乘加
    """
    assert A and B, "Empty matrices not allowed"
    n, m = len(A), len(A[0])
    assert all(len(row) == m for row in A), "A is not rectangular"
    assert len(B) > 0, "B is empty"
    mm, p = len(B), len(B[0])
    assert all(len(row) == p for row in B), "B is not rectangular"
    assert mm == m, "Inner dimensions must match"

    # TODO: 初始化结果矩阵 C，并完成三重循环
    C: Matrix = [[0+0j for _ in range(p)] for _ in range(n)]
    for i in range(n):
        for k in range(m):
            aik = A[i][k]
            for j in range(p):
                C[i][j] += aik * B[k][j]
    return C

if __name__ == "__main__":
    A = [[1+2j, 3-1j],
         [0+1j, -2+0j]]
    B = [[2-1j, 0+2j],
         [1+0j,  4-3j]]
    print(matmul_complex(A, B))
