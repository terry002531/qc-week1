# QC Week1 Starter

> Windows + PowerShell 快速起步包（与 blog 仓库无关，单独使用）

## 目录
- `hello_qiskit.py`：Aer 模拟器 1 比特例子
- `matmul_complex.py`：复数矩阵相乘（纯 Python 版，留空实现）
- `test_matmul_complex.py`：用 NumPy 对照验证
- `requirements.txt`：pip 安装依赖
- `environment.yml`：Conda 环境定义（Python 3.12）
- `.gitignore`：常用忽略项（Python/VSCode/OS）

## 使用方法（任选其一）

### A) pip（当前系统已有 Python）
```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python hello_qiskit.py
pytest -q
```

### B) Conda（推荐独立环境）
```powershell
conda env create -f environment.yml
conda activate qc
python hello_qiskit.py
pytest -q
```

## Git 初始化 & 推送到 GitHub（新仓库，避免和 blog 混淆）
```powershell
# 进入你的目标目录，例如 D:\Projects
# 把本压缩包解压到 qc-week1 目录，然后：
cd qc-week1
git init
git branch -M main
git add .
git commit -m "Week1: init"
# 之后在 GitHub 网站新建空仓库 qc-week1（不要勾 README），复制 SSH 地址：
git remote add origin git@github.com:<yourname>/qc-week1.git
git push -u origin main
```

## 验证
- 看到 `hello_qiskit.py` 输出 `{'0': ~50%, '1': ~50%}` 的计数
- `pytest -q` 通过（在你实现 `matmul_complex.py` 之后）

## 提示
- 如果 `qiskit_aer` 未装：`python -m pip install qiskit-aer`
- PowerShell 里不要直接输入 Bash 的 `<<EOF` 语法
- 本项目和你的 blog 是 **不同文件夹与不同仓库**，互不影响
```